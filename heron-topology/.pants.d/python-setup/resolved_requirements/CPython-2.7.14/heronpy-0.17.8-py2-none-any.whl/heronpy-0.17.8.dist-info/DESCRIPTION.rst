The heronpy package enables you to write Heron topologies in Python. Topologies can be run using a variety of schedulers, including Mesos/Aurora,Kubernetes, Mesos/Marathon, YARN, etc.



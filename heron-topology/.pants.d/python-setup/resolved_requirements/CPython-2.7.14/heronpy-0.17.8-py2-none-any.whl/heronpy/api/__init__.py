'''module for heronpy api'''
__import__('pkg_resources').declare_namespace(__name__)
